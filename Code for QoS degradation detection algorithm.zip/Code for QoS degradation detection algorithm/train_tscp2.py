import os
import pickle

import tensorflow as tf
from tensorflow import keras

import constants
from TSCP2.TSCP2Encoder import TSCP2Model
from config import TSCP2Config
from transformer import SeqTransformer
from qospreprocess import main as preprocess


def load(path):
    with open(path, 'rb') as f:
        return pickle.load(f)


def load_dataset(path, config):
    # load dataset
    train_data = load(path)

    train_dataset = tf.data.Dataset.from_tensor_slices(tuple(train_data[:2]))

    train_dataset = train_dataset.batch(config.batch,
                                        drop_remainder=True).prefetch(
        tf.data.experimental.AUTOTUNE
    )
    return train_dataset


def main():
    config = TSCP2Config("Train TSCP2 Encoder")
    config.update()
    config.print()

    train_dataset = load_dataset(os.path.join(constants.DATASET_PKL_DIR, 'pre.pkl'), config)
    print("Load Dataset Done")

    encoder = SeqTransformer(
        constants.feat_dim,
        constants.dim,
        constants.hidden_dim,
        constants.stack_count,
        constants.heads,
        constants.dropout
    )

    model = TSCP2Model(
        encoder=encoder, temperature=config.temperature,
        batch_size=config.batch
    )

    latest = tf.train.latest_checkpoint(
        checkpoint_dir=config.get_ckpt_dir("tscp2"))
    initial_epoch = 0
    if latest is not None:
        print("load model....")
        model.load_weights(latest)
        initial_epoch = int(os.path.basename(latest).split("-")[0])
        print("update initial_epoch ->", initial_epoch)
    model.compile(optimizer=keras.optimizers.Adam(config.lr), loss=None)

    callbacks = [
        keras.callbacks.ModelCheckpoint(
            filepath=config.get_ckpt_file("tscp2"),
            monitor="loss",
            verbose=2,
            save_best_only=False,
            save_weights_only=False,
        ),
        keras.callbacks.TensorBoard(
            log_dir=config.get_log_dir(config.model_name)),
    ]

    histroy = model.fit(
        train_dataset,
        epochs=initial_epoch + int(config.epoch),
        initial_epoch=initial_epoch,
        callbacks=callbacks,
        verbose=2
    )

    latest = tf.train.latest_checkpoint(config.get_ckpt_dir("tscp2"))
    model.load_weights(latest)
    print("Encoder Saving...")
    model.save(config.model_dir, save_format="tf")
    model.encoder.save(config.get_encoder_dir("tscp2"), save_format="tf")


if __name__ == "__main__":
    preprocess()
    main()
