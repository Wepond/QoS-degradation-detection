from typing import Dict
import os
import argparse
import time

import constants


class Config:
    def __init__(self, prog: str) -> None:
        self.prog = prog
        self.train_data_dir = "./dataset"
        self.test_data_dir = "./dataset"
        self.train_tscp2_data = None
        self.test_output_dir = "./test_output"
        self.model_output_dir = "./output"
        self.label = "demo"
        self.model_name = "base"
        self.mode = "train"  # or test or train-test
        self.update_path()

        self.lr = 0.0001
        self.epoch = 10
        self.batch = constants.BATCH_SIZE
        self._parser_ = argparse.ArgumentParser(prog)

    def init_parser(self):
        self._parser_.add_argument("--model_output_dir", type=str, default="output")
        self._parser_.add_argument("--test_output_dir", type=str, default="test_output")
        self._parser_.add_argument("--lr", help="learning rate", default=0.0001)
        self._parser_.add_argument("--epoch", default=10, type=int, help="epoch")
        self._parser_.add_argument("--batch", default=self.batch, type=int)
        self._parser_.add_argument("--mode", default=self.mode, type=str, help="train / predict / batch_test")
        self._parser_.add_argument(
            "--label",
            default=None,
            help="model label/name (default: now time)"
        )
        self._parser_.add_argument(
            "--train_data_dir",
            default=self.train_data_dir,
            type=str,
            help="Train dataset directory"
        )
        self._parser_.add_argument(
            "--train_tscp2_data",
            default=self.train_tscp2_data,
            type=str,
            help="Encoder training dataset directory"
        )
        self._parser_.add_argument(
            "--test_data_dir",
            default=self.test_data_dir,
            type=str,
            help="Test dataset directory"
        )

    def update_args(self):
        args = self._parser_.parse_args()

        self.train_data_dir = args.train_data_dir
        self.train_tscp2_data = args.train_tscp2_data
        self.test_data_dir = args.test_data_dir
        self.test_output_dir = args.test_output_dir
        self.model_output_dir = args.model_output_dir
        if args.label:
            self.label = args.label
        else:
            self.label = time.strftime("%Y%m%d-%H%M%S", time.localtime(time.time()))
        self.update_path()

        self.lr = float(args.lr)
        self.epoch = args.epoch
        self.batch = args.batch
        self.mode = args.mode

        return args

    def get_ckpt_dir(self, model_name: str):
        return os.path.join(self.model_output_dir, self.label, model_name, "ckpt")

    def get_fig_fir(self, model_name: str):
        return os.path.join(self.model_output_dir, self.label, model_name, "fig")

    def get_ckpt_file(self, model_name: str):
        return os.path.join(self.get_ckpt_dir(model_name), "{epoch:02d}-{loss:.6f}")

    def get_model_dir(self, model_name: str):
        return os.path.join(self.model_output_dir, self.label, model_name, "model")

    def get_encoder_dir(self, model_name: str):
        return os.path.join(self.model_output_dir, self.label, model_name, "encoder")

    def get_log_dir(self, model_name):
        return os.path.join(self.model_output_dir, self.label, model_name, "logs")

    def get_scaler_path(self):
        return os.path.join(self.model_output_dir, self.label, "scaler.pkl")

    def update_path(self):
        self.ckpt_dir = self.get_ckpt_dir(self.model_name)
        self.model_dir = self.get_model_dir(self.model_name)

    def dict(self) -> Dict:
        return {
            attr: getattr(self, attr)
            for attr in dir(self)
            if not callable(getattr(self, attr)) and not attr.startswith("_")
        }

    def update(self):
        self.init_parser()
        self.update_args()

    def print(self):
        print("{} Config: ".format(self.prog))
        for k, v in self.dict().items():
            print("\t{}: {}".format(k, v))


class MTQoSConfig(Config):
    def __init__(self, prog: str) -> None:
        super().__init__(prog)
        self.model_name = "mtqos"
        self.alpha = 10
        self.beta = 0.01
        self.windows = 32

    def init_parser(self):
        super().init_parser()
        self._parser_.add_argument("--alpha", type=float, default=self.alpha)
        self._parser_.add_argument("--beta", type=float, default=self.beta)
        self._parser_.add_argument("--windows", type=int, default=self.windows)

    def update_args(self):
        args = super().update_args()

        self.alpha = args.alpha
        self.beta = args.beta
        self.windows = args.windows


class TSCP2Config(Config):
    def __init__(self, prop) -> None:
        super().__init__(prop)
        self.model_name = "tscp2"
        self.windows: int = 32
        self.n_steps = 10
        self.code_size = 64
        self.temperature = 0.1

    def init_parser(self):
        super().init_parser()

        self._parser_.add_argument("--windows", type=int, default=32)
        self._parser_.add_argument("--n_steps", type=int, default=10)
        self._parser_.add_argument("--code_size", type=int, default=64)
        self._parser_.add_argument(
            "--temperature", type=float, default=self.temperature
        )

    def update_args(self):
        args = super().update_args()

        self.windows = args.windows
        self.n_steps = args.n_steps
        self.code_size = args.code_size
        self.temperature = args.temperature

        return args


class TSTCCConfig(Config):
    def __init__(self, prop) -> None:
        super().__init__(prop)
        self.model_name = "tstcc"

        # TSTCCModel
        self.sim = "dot"  # or consine
        self.temperature = 0.1
        # loss = tc_loss * lambda1 + ctx_loss * lambda2
        self.lambda1 = 0.9
        self.lambda2 = 0.99

        # TC
        self.n_channels = 128
        self.n_hidden = 100
        self.n_stack = 2
        self.heads = 4
        self.mlp_dim = 64
        self.dropout = 0.35
        self.timesteps = 10

    def init_parser(self):
        super().init_parser()

        self._parser_.add_argument("--windows", type=int, default=32)
        self._parser_.add_argument("--n_steps", type=int, default=10)
        self._parser_.add_argument("--code_size", type=int, default=64)
        self._parser_.add_argument(
            "--temperature", type=float, default=self.temperature
        )

    def update_args(self):
        args = super().update_args()

        self.windows = args.windows
        self.n_steps = args.n_steps
        self.code_size = args.code_size
        self.temperature = args.temperature

        return args


if __name__ == "__main__":
    config = Config("base config")
    config.update()
    config.print()

    config = MTQoSConfig("MTQoSConfig")
    config.update()
    config.print()

    config = TSCP2Config("TSCP2Config")
    config.update()
    config.print()
