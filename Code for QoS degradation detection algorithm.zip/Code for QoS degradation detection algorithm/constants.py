# preprocess
WINDOWS = 16
VAL_DATASET_RATIO = 0
DATASET_STEP = 5
HOST_METRICS_USED = True

DATASET_PKL_DIR = "./cache/dataset_pkl"
TEST_PKL_DIR = "./cache/test_pkl"
VM_METRICS_FILE = "./metrics/vm_metrics"
HOST_METRICS_FILE = "./metrics/host_metrics"

DELTA_COLUMN = "delta_qos"

TRAIN_APPS = [
    "etcd", "mongoDB", "rabbitmq", "redis", "cassandra",
    "hbase", "kafka", "ignite", "elasticsearch", "postgresql",
    "ab", "ffmpeg", "mysql", "gromacs"
]
TEST_APPS = ["kafka", "ignite", "elasticsearch", "postgresql"]

DATASET_SUFFIX = ".csv"

# encoder parameters
feat_dim = 71
dim = 256  # Embedding 
heads = 8  # MultiAttention 
assert (dim % heads == 0)
hidden_dim = 256  # FeedForward 
stack_count = 6  # Transformer 
dropout = 0.15

# experiments.py
BATCH_SIZE = 128
TASK_SIZE = BATCH_SIZE * 1000  
REPLAY_BUFFER_SIZE = 102000 
REPLAY_SAMPLE_SIZE = 10000  
REPLAY_REPLACEMENT_RATE = 0.05
REPLAY_EPOCH = 1
