import os
import pickle
import random
import shutil

import numpy as np
import pandas as pd
from sklearn.preprocessing import MinMaxScaler, StandardScaler

import constants
from config import Config

random.seed(42)
np.random.seed(42)


def data_features_list(host_metrics=True):
    """

    Args:
        host_metrics: whether to use host metrics

    Returns: vm_metrics + host_metrics(if host_metrics is True)

    """
    event_file_list = [constants.VM_METRICS_FILE]
    features = []
    if host_metrics:
        event_file_list.append(constants.HOST_METRICS_FILE)
    for file_name in event_file_list:
        with open(file_name, 'r') as eventsFile:
            for line in eventsFile.readlines():
                event = line.strip()
                features.append(event)
    if not features:
        raise Exception("event file is empty")
    return features


def get_app_label(data, path):
    """
    generate app label by dataset path
    """
    label = len(constants.TRAIN_APPS)
    filename = os.path.basename(path)
    for i in range(len(constants.TRAIN_APPS)):
        if filename.startswith(constants.TRAIN_APPS[i]) or \
                filename.startswith("0-") and constants.TRAIN_APPS[i] in filename or \
                "vm" in filename and constants.TRAIN_APPS[i] in filename:
            label = i
            break
    return np.ones(len(data), dtype=int) * label


def save(data_obj, filename, pkl_dir):
    if not os.path.exists(pkl_dir):
        os.makedirs(pkl_dir)
    with open(os.path.join(pkl_dir, filename), 'wb') as out:
        pickle.dump(data_obj, out, protocol=4)


def generate_scaler(paths, cols, save_path=None):
    if os.path.exists(save_path):
        with open(save_path, "rb") as f:
            scaler = pickle.load(f)
        return scaler

    perf_data = np.vstack([pd.read_csv(path)[cols].values for path in paths])
    scaler = MinMaxScaler()
    scaler.fit(perf_data)

    # 设置常数列最小值为 0
    scaler.data_min_[3:5] = 0
    scaler.data_min_[-4:] = 0
    scaler.scale_ = 1 / (scaler.data_max_ - scaler.data_min_)
    scaler.min_ = -scaler.data_min_ * scaler.scale_

    if save_path is not None:
        if not os.path.exists(os.path.dirname(save_path)):
            os.makedirs(os.path.dirname(save_path))
        with open(save_path, 'wb') as out:
            pickle.dump(scaler, out)

    return scaler


def load_labeled_data(paths, windows, cols, filename, scaler,
                      shuffle=True, pkl_dir=None, step=constants.DATASET_STEP):
    # history, future, delta, app_label
    seq_processed = [[], [], [], []]
    for path in paths:
        data = pd.read_csv(path)
        if len(data) < windows:
            continue

        data_x = scaler.transform(data[cols].values)
        data_delta = data[[constants.DELTA_COLUMN]].values
        data_app_label = get_app_label(data, path)

        extracted_data = extract_windows(data_x, data_delta, data_app_label, windows, step)
        for i in range(len(extracted_data)):
            seq_processed[i].extend(extracted_data[i])

    dump_data = [np.stack(seq_processed[i], axis=0).astype(np.float32) for i in range(len(seq_processed) - 1)]
    dump_data.append(np.eye(len(constants.TRAIN_APPS) + 1)[
                         np.hstack(seq_processed[-1]).astype(np.int32)])
    print("data shape: ", dump_data[0].shape, dump_data[2].shape, dump_data[3].shape)

    if shuffle:
        print('shuffle')
        idx = np.arange(dump_data[0].shape[0])
        np.random.shuffle(idx)
        for i in range(len(dump_data)):
            dump_data[i] = dump_data[i][idx, :]

    save(dump_data, filename, pkl_dir)


def load_unlabeled_data(path, windows, cols, scaler, step=constants.DATASET_STEP):
    data = pd.read_csv(path)
    data_x = scaler.transform(data[cols].values)

    seq_processed = [data_x[i: i + windows, :] for i in
                     range(0, len(data_x) - windows, step)]

    return np.stack(seq_processed, axis=0).astype(np.float32)


def extract_windows(data_x, data_delta, data_app_label, windows=constants.WINDOWS,
                    step=5):
    """
    Args
        data_x: vm_metrics
        data_delta:
        data_app_label: app label: redis/mongoDB/hbase
        windows: default WINDOWS
        step: default 5

    Returns:history_seq, future_seq, delta, app_label
    """
    history_seq, future_seq, delta, app_label = [], [], [], []
    data_length = len(data_x)
    for i in range(0, data_length - 2 * windows, step):
        history_seq.append(data_x[i: i + windows, :])
        future_seq.append(data_x[i + windows: i + 2 * windows, :])
        delta.append(data_delta[i + windows - 1, :])
        app_label.append(data_app_label[i + windows - 1])
    return history_seq, future_seq, delta, app_label


def scan_dir(data_dir):
    data_path_list = []
    for filename in os.listdir(data_dir):
        cur_path = os.path.join(data_dir, filename)
        if filename.endswith(constants.DATASET_SUFFIX):
            data_path_list.append(cur_path)
        elif os.path.isdir(cur_path):
            data_path_list += scan_dir(cur_path)
    return data_path_list


def load_paths(data_dir, train=True):
    data_path_list = scan_dir(data_dir)
    random.shuffle(data_path_list)
    if train:
        train_len = round(len(data_path_list) * constants.VAL_DATASET_RATIO)
        val_len = train_len if constants.VAL_DATASET_RATIO != 0 else round(len(data_path_list) * 0.1)
        return data_path_list[train_len:], data_path_list[:val_len]
    else:
        return data_path_list


def main():
    config = Config("Preprocess")
    config.update()

    features = data_features_list(constants.HOST_METRICS_USED)
    if config.mode == 'train':
        train_paths, val_paths = load_paths(config.train_data_dir)
        test_paths = load_paths(config.test_data_dir, train=False)
        pre_paths = load_paths(config.train_tscp2_data,
                               train=False) if config.train_tscp2_data else train_paths + val_paths

        filename_list = ['pre.pkl', 'train.pkl', 'val.pkl', 'test.pkl']
        path_list = [pre_paths, train_paths, val_paths, test_paths]

        scaler = generate_scaler(pre_paths, features, config.get_scaler_path())
        for path, filename in zip(path_list, filename_list):
            load_labeled_data(path, constants.WINDOWS, features, filename,
                              scaler=scaler, shuffle=True,
                              pkl_dir=constants.DATASET_PKL_DIR)
    elif config.mode == 'batch_test':
        if os.path.exists(constants.TEST_PKL_DIR):
            shutil.rmtree(constants.TEST_PKL_DIR)
        os.makedirs(constants.TEST_PKL_DIR)

        with open(config.get_scaler_path(), "rb") as f:
            scaler = pickle.load(f)

        test_paths = [os.path.join(config.test_data_dir, filename) for filename in
                      os.listdir(config.test_data_dir)]

        for test_dir in test_paths:
            if os.path.isfile(test_dir):
                continue
            output_filename = os.path.basename(test_dir) + '.pkl'
            cur_test_paths = [os.path.join(test_dir, filename) for filename in
                              os.listdir(test_dir)]
            load_labeled_data(cur_test_paths, constants.WINDOWS, features, output_filename,
                              scaler=scaler, shuffle=False, pkl_dir=constants.TEST_PKL_DIR, step=1)
    elif config.mode == "predict":
        with open(config.get_scaler_path(), "rb") as f:
            scaler = pickle.load(f)

        raw_paths, dataset = [], []
        for filename in os.listdir(config.test_data_dir):
            cur_test_path = os.path.join(config.test_data_dir, filename)
            if os.path.isdir(cur_test_path):
                continue

            raw_paths.append(cur_test_path)
            dataset.append(load_unlabeled_data(cur_test_path, constants.WINDOWS, features, scaler=scaler, step=1))

        return raw_paths, dataset
    elif config.mode == "predict_all_file":
        return scan_dir(config.test_data_dir)

    return 0


if __name__ == "__main__":
    main()
