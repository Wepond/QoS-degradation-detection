import numpy as np
import tensorflow as tf
from tensorflow import keras

import constants
from TSCP2.TSCP2Encoder import TSCP2Model
from model_base import MTQoSModel
import random
import gc

def generate_replay_data(data, delta, label):
    train_dataset = tf.data.Dataset.from_tensor_slices(
        (data, delta, label))

    train_data = train_dataset.batch(constants.BATCH_SIZE,
                                     drop_remainder=True).prefetch(
        tf.data.experimental.AUTOTUNE
    )
    return train_data


class ContinualLearningModel:
    def __init__(self, name="None", replay_buffer=3100,
                 encoder=None):
        print("> Continual Learning Model Initiated")
        self.encoder = encoder
        self.tscp2_model = None
        self.model = None
        self.name = name
        self.replay_buffer = replay_buffer

        self.replay_representations_x = []
        self.replay_representations_delta = []
        self.replay_representations_label = []

    def build_complete_model(self, config):

        self.tscp2_model = TSCP2Model(
            encoder=self.encoder, temperature=0.1, batch_size=config.batch
        )

        # try to load pre model
        latest = tf.train.latest_checkpoint(
            checkpoint_dir=config.get_ckpt_dir("tscp2"))
        if latest is not None:
            print("load pre model....")
            self.tscp2_model.load_weights(latest)

        self.model = MTQoSModel(encoder=self.tscp2_model.encoder)
        self.model.compile(optimizer=keras.optimizers.Adam(config.lr))

    def replay(self, callbacks):

        replay_x = np.array(self.replay_representations_x)
        replay_delta = np.array(self.replay_representations_delta)
        replay_label = np.array(self.replay_representations_label)

        print("> REPLAYING")
        dataset = generate_replay_data(replay_x, replay_delta, replay_label)
        self.model.fit(dataset, epochs=constants.REPLAY_EPOCH, verbose=2, batch_size=constants.BATCH_SIZE,
                       callbacks=callbacks)

    def store_representations(self, train_x, train_delta, train_label,
                              random_select=False):

        replay_memory_size = len(self.replay_representations_x) + constants.REPLAY_SAMPLE_SIZE
        replacement_batch_size = int(self.replay_buffer * constants.REPLAY_REPLACEMENT_RATE)

        if random_select:
            if replay_memory_size >= self.replay_buffer:
                x_sample, delta_sample, label_sample = zip(
                    *random.sample(
                        list(zip(train_x, train_delta, train_label)),
                        replacement_batch_size))


                patterns_to_delete = random.sample(
                    range(0, len(self.replay_representations_x) - 1),
                    replacement_batch_size)
                for pat in sorted(patterns_to_delete, reverse=True):
                    del self.replay_representations_x[pat]
                    del self.replay_representations_delta[pat]
                    del self.replay_representations_label[pat]
            else:
                x_sample, delta_sample, label_sample = zip(
                    *random.sample(
                        list(zip(train_x, train_delta, train_label)),
                        constants.REPLAY_SAMPLE_SIZE))

        else:
            x_sample = train_x
            delta_sample = train_delta
            label_sample = train_label

            if replay_memory_size >= self.replay_buffer:
                self.replay_representations_x = self.replay_representations_x[
                                                len(x_sample):len(
                                                    self.replay_representations_x)]
                self.replay_representations_delta = self.replay_representations_delta[
                                                    len(x_sample):len(
                                                        self.replay_representations_delta)]
                self.replay_representations_label = self.replay_representations_label[
                                                    len(x_sample):len(
                                                        self.replay_representations_label)]

        for i in range(len(x_sample)):
            self.replay_representations_x.append(x_sample[i])
            self.replay_representations_delta.append(delta_sample[i])
            self.replay_representations_label.append(label_sample[i])

        gc.collect()
        print("Replay X: ", len(self.replay_representations_x),
              " Replay delta: ", len(self.replay_representations_delta),
              " Replay label: ", len(self.replay_representations_label))
