import os
import pickle

import numpy as np
import pandas as pd
import tensorflow as tf

from tensorflow import keras

import constants

from config import MTQoSConfig
from model_base import MTQoSModel
from transformer import SeqTransformer
from qospreprocess import load_unlabeled_data, data_features_list
from experiments import Experiments, load_dataset, generate_train_data

from qospreprocess import main as preprocess
from train_tscp2 import main as train_encoder

gpus = tf.config.experimental.list_physical_devices('GPU')
if len(gpus) > 0:
    tf.config.experimental.set_visible_devices(gpus[0], 'GPU')
    tf.config.experimental.set_memory_growth(gpus[0], True)

encoder = SeqTransformer(constants.feat_dim,
                         constants.dim,
                         constants.hidden_dim,
                         constants.stack_count,
                         constants.heads,
                         constants.dropout)


def init_model():
    model = MTQoSModel(encoder=encoder)
    model.compile(optimizer=keras.optimizers.Adam(config.lr))

    latest_filenames = [filename for filename in os.listdir(os.path.join(config.model_output_dir, config.label)) if
                        "replay_mtqos" in filename]
    latest_filenames.sort(key=len)

    print("use ckpt: ", latest_filenames[-1])
    latest = tf.train.latest_checkpoint(
        config.get_ckpt_dir(str(latest_filenames[-1])))
    model.load_weights(latest).expect_partial()

    return model


def get_classify_accuracy_df(path, data):
    filename = os.path.basename(path)

    data.drop(data.head(constants.WINDOWS).index, inplace=True)
    accuracy_df = data["predict_app_name"].apply(lambda x: filename.startswith(x) or filename.startswith(
        "0-") and x in filename or "vm" in filename and x in filename)
    return accuracy_df


if __name__ == "__main__":
    config = MTQoSConfig("Train MTQoSModel")
    config.update()
    config.print()

    if config.mode == 'train':
        preprocess()

        if config.epoch > 0:
            train_encoder()

        experiments = Experiments(encoder=encoder)
        print("> Experiment: Continual Learning VS Transfer Learning")
        experiments.run_replay_experiment(experiment_name="CONTINUAL_LEARNING",
                                          use_case="Continual Learning",
                                          replay_size=constants.REPLAY_BUFFER_SIZE,
                                          random_selection=True,
                                          config=config)
    elif config.mode == 'batch_test':
        preprocess()
        test_model = init_model()
        mae_mean = []
        for test_file in os.listdir(constants.TEST_PKL_DIR):
            test_data, test_delta, test_label = load_dataset(os.path.join(constants.TEST_PKL_DIR, test_file))
            test_dataset = generate_train_data(test_data, test_delta, test_label)

            print('Testing: ' + test_file)
            mae_mean.append(test_model.evaluate(test_dataset)[3])
        print("---------------overall MAE -----------------")
        print(np.mean(mae_mean))
    elif config.mode == 'predict':
        raw_paths, raw_test_dataset = preprocess()
        test_model = init_model()

        columns = ["predict_" + constants.DELTA_COLUMN, "predict_app_type", "predict_app_name"]
        placeholder = pd.DataFrame(
            np.zeros((constants.WINDOWS, len(columns)), dtype=int),
            columns=columns
        )

        for raw_path, raw_test_data in zip(raw_paths, raw_test_dataset):
            if not os.path.exists(config.test_output_dir):
                os.makedirs(config.test_output_dir)

            raw_df = pd.read_csv(raw_path)

            delta_pre, label_pre = test_model.predict(raw_test_data)

            exist_apps = constants.TRAIN_APPS + ["Unknown"]
            app_label_list = np.argmax(label_pre, axis=1)
            app_name_list = [exist_apps[i] for i in app_label_list]
            delta_pre_df = pd.concat([placeholder,
                                      pd.DataFrame(np.vstack([np.squeeze(delta_pre), app_label_list, app_name_list]).T,
                                                   columns=columns)], ignore_index=True)
            raw_df = pd.concat([raw_df, delta_pre_df], axis=1)

            mae = raw_df.apply(
                lambda x: abs(float(x[constants.DELTA_COLUMN]) - float(x["predict_" + constants.DELTA_COLUMN])),
                axis=1).mean()

            cur_output_path = os.path.join(config.test_output_dir,
                                           os.path.basename(raw_path).replace(
                                               constants.DATASET_SUFFIX, "-predicted" + constants.DATASET_SUFFIX))

            print("MAE: {:.3}, Saved in {}".format(mae, cur_output_path))
            raw_df.to_csv(cur_output_path, index=False)
    elif config.mode == 'predict_all_file':
        raw_paths = preprocess()
        test_model = init_model()
        features = data_features_list(constants.HOST_METRICS_USED)
        with open(config.get_scaler_path(), "rb") as f:
            scaler = pickle.load(f)

        columns = ["predict_" + constants.DELTA_COLUMN, "predict_app_type", "predict_app_name"]
        placeholder = pd.DataFrame(
            np.zeros((constants.WINDOWS, len(columns)), dtype=int),
            columns=columns
        )

        accuracy_sum, count = 0, 0
        for raw_path in raw_paths:
            if not os.path.exists(config.test_output_dir):
                os.makedirs(config.test_output_dir)

            raw_df = pd.read_csv(raw_path)
            raw_test_data = load_unlabeled_data(raw_path, constants.WINDOWS, features, scaler=scaler, step=1)

            delta_pre, label_pre = test_model.predict(raw_test_data)

            exist_apps = constants.TRAIN_APPS + ["Unknown"]
            app_label_list = np.argmax(label_pre, axis=1)
            app_name_list = [exist_apps[i] for i in app_label_list]
            delta_pre_df = pd.concat([placeholder,
                                      pd.DataFrame(np.vstack([np.squeeze(delta_pre), app_label_list, app_name_list]).T,
                                                   columns=columns)], ignore_index=True)
            raw_df = pd.concat([raw_df, delta_pre_df], axis=1)

            accuracy_df = get_classify_accuracy_df(raw_path, raw_df)
            cur_accuracy = accuracy_df.mean()
            accuracy_sum += accuracy_df.sum()
            count += len(accuracy_df)

            mae = raw_df.apply(
                lambda x: abs(float(x[constants.DELTA_COLUMN]) - float(x["predict_" + constants.DELTA_COLUMN])),
                axis=1).mean()

            cur_output_path = os.path.join(config.test_output_dir,
                                           os.path.basename(raw_path).replace(
                                               constants.DATASET_SUFFIX, "-predicted" + constants.DATASET_SUFFIX))

            if cur_accuracy < 1:
                print("MAE: {:.3}; Accuracy: {:.3}; Path: {}".format(mae, cur_accuracy, raw_path))
            # print("MAE: {:.3}; Accuracy: {:.3}; Saved in {}".format(mae, cur_accuracy, cur_output_path))
            # raw_df.to_csv(cur_output_path, index=False)

        print("Total accuracy: {:6f}".format(accuracy_sum / count))
