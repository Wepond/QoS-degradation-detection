import numpy as np
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import Model, layers


class FixedPositionalEncodingLayer(layers.Layer):
    """Positional Encoding

    Reference:
        https://github.com/sherlocked27/transformer_tf2.0/blob/c18def3f561cea7606e1771d72c244ebd25e6b5a/transformer.py#L5
    """

    def __init__(self, dim: int, dropout: float = 0.1):
        """Fixed Positional Encoding

        Args:
            dim (int): input dim
            dropout (float, optional): dropout rate. Defaults to 0.1.
        """
        super(FixedPositionalEncodingLayer, self).__init__()
        self.d_model = dim
        self.dropout = layers.Dropout(dropout)

    def call(self, inputs, **kwargs):
        """Fixed Positional Encoding

        Args:
            inputs (tf.Tensor): shape is (batch_size, seq_len, dim)

        Returns:
            _type_: inputs with positional encoding, shape is (batch_size, seq_len, dim)
        """
        max_length = inputs.shape[1]

        # [[1],[2]] + np.expand_dims([1], axis=0) = array([[2],[3]])
        inputs += self.positionalEncoding(max_length, self.d_model)
        return self.dropout(inputs)

    def positionalEncoding(self, max_len: int, dim: int):
        """Generate the positional encoding.

        Args:
            max_len (int): max length of input
            dim (int): dim of input

        Returns:
            _type_: positional encoding
        """
        pe: np.ndarray = np.array(
            [
                [pos / (10000 ** ((2 * i) / dim)) for i in range(dim)]
                if pos != 0
                else np.zeros(dim)
                for pos in range(max_len)
            ]
        )
        pe[:, ::2] = np.sin(pe[:, ::2])
        pe[:, 1::2] = np.cos(pe[:, 1::2])
        pe = np.expand_dims(pe, axis=0)  # To incoperate the batch size
        return tf.cast(pe, dtype=tf.float32)


class MultiAttentionLayer(layers.Layer):
    """Multi-Head Attention Layer"""

    def __init__(self, dim: int, heads: int = 8, dropout: float = 0.1):
        """Multi-Head Attention Layer

        Args:
            dim (int): input dim
            heads (int, optional): number of heads. Defaults to 8.
            dropout (float, optional): dropout rate. Defaults to 0.1.
        """
        super(MultiAttentionLayer, self).__init__()
        self.dim = dim
        self.scale = dim ** -0.5
        self.heads = heads
        self.dropout = dropout

        self.to_qkv = layers.Dense(dim * 3, use_bias=False)
        self.to_out = keras.Sequential(
            [layers.Dense(dim), layers.Dropout(dropout)])
        self.depth = dim // self.heads

    def split_head(self, x, batch: int):
        """Split the last dimension and transpose into (batch, heads, dim/heads)

        Args:
            x (tf.Tensor): shape is (batch, seq, dim)
            batch (int): batch size

        Returns:
            _type_: shape is (batch, heads, seq, dim/heads)
        """
        # [batch, seq, dim] -> [batch, seq, head, depth]
        x = tf.reshape(x, (batch, -1, self.heads, self.depth))

        # [batch, seq, head, depth] -> [batch, head, seq, depth]
        x = tf.transpose(x, perm=[0, 2, 1, 3])
        return x

    def call(self, inputs, mask=None, training=None, **kwargs):
        """Multi-Head Attention Layer

        Args:
            inputs (tf.Tensor): shape is (batch, seq, dim)
            mask (tf.Tensor, optional): mask for attention. Defaults to None.
            training (bool, optional): training or not. Defaults to None.

        Returns:
            _type_: shape is (batch, seq, dim)
        """
        batch = tf.shape(inputs)[0]

        qkv = self.to_qkv(inputs)
        q, k, v = tf.split(qkv, num_or_size_splits=3, axis=-1)
        q = self.split_head(q, batch)
        k = self.split_head(k, batch)
        v = self.split_head(v, batch)

        # [batch, head, seq, seq]
        scaled_dots = tf.einsum("bhid,bhjd->bhij", q, k) * self.scale

        if mask is not None:
            scaled_dots += mask * -1e9

        attn = tf.nn.softmax(scaled_dots, axis=-1)

        out = tf.einsum("bhij,bhjd->bhid", attn, v)

        # [batch, head, seq, depth] -> [batch, seq, head, depth]
        out = tf.transpose(out, perm=[0, 2, 1, 3])
        # [batch, seq, head, depth] -> [batch, seq, dim]
        out = tf.reshape(out, shape=[batch, -1, self.dim])

        out = self.to_out(out)
        return out


class FeedForward(layers.Layer):
    def __init__(self, dim, hidden_dim, dropout, *args, **kwargs):
        """Feed Forward Layer

        Args:
            dim (int): input dim
            hidden_dim (int): hidden dim
            dropout (float): dropout rate
        """
        super(FeedForward, self).__init__(*args, **kwargs)

        self.model = keras.Sequential(
            [
                layers.Dense(hidden_dim),
                layers.ReLU(),
                layers.Dropout(dropout),
                layers.Dense(dim),
                layers.Dropout(dropout),
            ]
        )

    def call(self, inputs, training=None, mask=None):
        """Feed Forward Layer

        Args:
            inputs (tf.Tensor): shape is (batch, seq, dim)
            training (bool, optional): training or not. Defaults to None.
            mask (tf.Tensor, optional): mask for attention. Defaults to None.

        Returns:
            _type_: (tf.Tensor), shape is (batch, seq, dim)
        """
        return self.model(inputs, training=training, mask=mask)


class TransformerEncoder(layers.Layer):
    def __init__(self, dim, heads, hidden_dim, dropout, *args, **kwargs):
        """Transformer Encoder Layer

        Args:
            dim (int): input dim
            heads (int): number of heads
            hidden_dim (int): hidden dim
            dropout (float): dropout rate
        """
        super(TransformerEncoder, self).__init__(*args, **kwargs)
        self.dim = dim
        self.heads = heads
        self.hidden_dim = hidden_dim
        self.dropout = dropout

        self.multi_attn = MultiAttentionLayer(dim, heads, dropout)
        self.ff = FeedForward(dim, hidden_dim, dropout)
        self.layer_norm_1 = layers.LayerNormalization(epsilon=1e-6)
        self.layer_norm_2 = layers.LayerNormalization(epsilon=1e-6)

    def call(self, inputs, padding_mask=None, training=False, **kwargs):
        """Transformer Encoder Layer

        Args:
            inputs (tf.Tensor): shape is (batch, seq, dim)
            padding_mask (tf.Tensor, optional): padding mask. Defaults to None.
            training (bool, optional): training or not. Defaults to False.

        Returns:
            _type_: (tf.Tensor), shape is (batch, seq, dim)
        """
        attn_out = self.multi_attn(inputs, padding_mask, training=training)
        attn_out = self.layer_norm_1(inputs + attn_out)

        ff_out = self.ff(attn_out, training=training)
        ff_out = self.layer_norm_2(attn_out + ff_out)
        return ff_out


class SeqTransformer(Model):
    """Seq Transformer, TS-TCC"""

    def __init__(
            self,
            feat_dim,
            dim=64,
            hidden_dim=128,
            stack_count=2,
            heads=8,
            dropout=0.1,
            *args,
            **kwargs
    ):
        """Seq Transformer, TS-TCC

        Args:
            feat_dim (int): feature dim
            dim (int, optional): transformer dim. Defaults to 64.
            hidden_dim (int, optional): feed forward dim. Defaults to 128.
            stack_count (int, optional): number of transformer layers.
                                        Defaults to 2.
            heads (int, optional): number of heads. Defaults to 8.
            dropout (float, optional): dropout rate. Defaults to 0.1.

        Raises:
            ValueError: if stack_count is not positive
        """
        super(SeqTransformer, self).__init__(*args, **kwargs)
        self.feat_dim = feat_dim
        self.dim = dim
        self.heads = heads
        self.hidden_dim = hidden_dim
        self.dropout = dropout
        self.stack_count = stack_count

        self.embedding = layers.Dense(dim)
        self.pos_enc = FixedPositionalEncodingLayer(dim, dropout)
        self.encoders = []
        for i in range(stack_count):
            encoder = TransformerEncoder(dim, heads, hidden_dim, dropout)
            self.encoders.append(encoder)

        self.c_token = tf.Variable(tf.random.uniform([1, 1, dim]))
        self.out = layers.Dense(feat_dim)

    def call(self, inputs, training=False, **kwargs):
        """Seq Transformer

        Args:
            inputs (tf.Tensor): shape is (batch, seq, feat_dim)
            training (bool, optional): training or not. Defaults to False.

        Returns:
            _type_: (tf.Tensor), shape is (batch, feat_dim)
        """
        batch = tf.shape(inputs)[0]
        x = self.embedding(inputs)
        x = self.pos_enc(x, training=training)

        # [batch, seq, dim]
        c_tokens = tf.repeat(self.c_token, repeats=batch, axis=0)

        x = tf.concat([x, c_tokens], axis=1)

        for encoder in self.encoders:
            x = encoder(x, training=training)

        c_t = tf.identity(x[:, 0])
        return c_t
