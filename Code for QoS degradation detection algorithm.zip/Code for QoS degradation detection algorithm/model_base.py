import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers

import constants

categorical_crossentropy = tf.keras.losses.CategoricalCrossentropy()
huber_loss = tf.keras.losses.Huber(0.3)


class MTQoSModel(tf.keras.Model):
    def __init__(
            self,
            encoder: keras.Model,
            hidden_1: int = 512,
            hidden_2: int = 128,
            label_hidden: int = 256,
            n_delta: int = 1,
            n_label: int = len(constants.TRAIN_APPS) + 1,
            lambda1: float = 0.9,
            lambda2: float = 0.1,
            *args,
            **kwargs
    ) -> None:
        super(MTQoSModel, self).__init__(*args, **kwargs)
        self.encoder = encoder

        self.delta_fc = keras.Sequential(
            [layers.Dense(hidden_1), layers.ReLU(), layers.Dense(hidden_2), layers.ReLU(), layers.Dense(n_delta)]
        )

        self.label_fc = keras.Sequential(
            [
                layers.Dense(label_hidden),
                layers.Dropout(0.1),
                layers.ReLU(),
                layers.Dense(n_label, activation="softmax"),
            ]
        )

        self.mean_loss = keras.metrics.Mean("loss")
        self.crossentropy = keras.metrics.Mean("crossentropy")
        self.huber = keras.metrics.Mean("huber")
        self.rmse = tf.keras.metrics.RootMeanSquaredError("rmse")
        self.mae = tf.keras.metrics.MeanAbsoluteError("mae")

        self.lambda1 = tf.constant(lambda1)
        self.lambda2 = tf.constant(lambda2)

    def call(self, inputs, training=None, mask=None):
        # inputsArr = [self.lstm(conv(inputs)) for conv in self.convs]
        # inputs = tf.concat(inputsArr, axis=1)
        code = self.encoder(inputs, training=training, mask=mask)
        delta = self.delta_fc(code, training=training, mask=mask)
        label = self.label_fc(code, training=training, mask=mask)

        return delta, label

    @tf.function
    def train_step(self, data):
        X, *y = data
        with tf.GradientTape() as tape:
            y_pred = self(X, training=True)
            delta_true, label_true = y
            delta_pred, label_pred = y_pred
            huber = huber_loss(delta_true, delta_pred)
            crossentropy = categorical_crossentropy(label_true, label_pred)
            loss = self.lambda1 * huber + self.lambda2 * crossentropy

        self.mean_loss.update_state(loss)
        self.huber.update_state(huber)
        self.crossentropy.update_state(crossentropy)
        self.rmse.update_state(delta_true, delta_pred)
        self.mae.update_state(delta_true, delta_pred)

        trainable_vars = self.trainable_variables
        gradients = tape.gradient(loss, trainable_vars)
        self.optimizer.apply_gradients(zip(gradients, trainable_vars))

        return {
            "loss": self.mean_loss.result(),
            "huber": self.huber.result(),
            "rmse": self.rmse.result(),
            "mae": self.mae.result(),
            "crossentropy": self.crossentropy.result(),
        }

    @tf.function
    def test_step(self, data):
        X, *y = data
        y_pred = self(X, training=False)
        delta_true, label_true = y
        delta_pred, label_pred = y_pred
        huber = huber_loss(delta_true, delta_pred)
        crossentropy = categorical_crossentropy(label_true, label_pred)
        loss = self.lambda1 * huber + self.lambda2 * crossentropy

        self.mean_loss.update_state(loss)
        self.huber.update_state(huber)
        self.crossentropy.update_state(crossentropy)
        self.rmse.update_state(delta_true, delta_pred)
        self.mae.update_state(delta_true, delta_pred)

        print('test finished.')

        return {
            "loss": self.mean_loss.result(),
            "huber": self.huber.result(),
            "rmse": self.rmse.result(),
            "mae": self.mae.result(),
            "crossentropy": self.crossentropy.result(),
        }

    @tf.function
    def predict_step(self, data):
        return self(data, training=False)

    @property
    def metrics(self):
        return [self.mean_loss, self.huber, self.rmse, self.mae, self.crossentropy]
