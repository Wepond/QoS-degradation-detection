import typing
import numpy as np
import tensorflow as tf
from tensorflow import math
from tensorflow import keras
from tensorflow.keras.layers import Input, Flatten, Dense, Activation
from tensorflow.keras import Model
from tensorflow.keras import backend as K
# from tcn import TCN
from tensorflow.python.framework.ops import Tensor

import constants

cosine_sim_2d = tf.keras.losses.CosineSimilarity(
    axis=2, reduction=tf.keras.losses.Reduction.NONE
)


@tf.function
def cosine_sim(x, y):
    v = cosine_sim_2d(tf.expand_dims(x, 1), tf.expand_dims(y, 0))
    # res =  -tf.matmul(tf.expand_dims(x, 1), tf.expand_dims(y, 2))
    # print('cos, ', x.shape, y.shape, v.shape)
    return -v


class NCELoss:
    def __init__(
            self,
            batch_size: int = constants.BATCH_SIZE,
            sim: typing.Callable = cosine_sim,
            temperature: float = 0.1,
    ) -> None:
        self.similarity = sim
        self.criterion = tf.keras.losses.BinaryCrossentropy(
            from_logits=True, reduction=tf.keras.losses.Reduction.SUM
        )
        self.N = batch_size
        self.temperature = temperature

        self.tri_mask = np.ones(shape=(self.N, self.N), dtype=np.bool8)
        self.tri_mask[np.diag_indices(self.N)] = False
        self.label = np.ones(self.N)

    def __call__(self, history, future):
        sim = self.similarity(history, future)
        pos_sim: typing.Any = tf.linalg.tensor_diag_part(sim)
        pos_sim = K.exp(pos_sim / self.temperature)

        neg = tf.reshape(tf.boolean_mask(sim, self.tri_mask), [self.N, self.N - 1])
        all_sim = K.exp(sim / self.temperature)
        logits = tf.divide(K.sum(pos_sim), K.sum(all_sim, axis=1))
        loss = self.criterion(y_pred=logits, y_true=self.label)
        mean_sim = K.mean(tf.linalg.tensor_diag_part(sim))
        mean_neg = K.mean(neg)
        return loss, mean_sim, mean_neg


def build_tcn_model(
        fshape: typing.Tuple,
        n_steps: int,
        code_size: int,
        n_batch: int = constants.BATCH_SIZE,
        nb_filters: int = 64,
        kernel_size: int = 4,
        nb_stacks: int = 2,
        dilations: typing.List[int] = [1, 2, 4, 8],
        padding: str = "causal",
        use_skip_connections: bool = True,
        dropout_rate: float = 0.0,
        activation: str = "relu",
):
    inputs = Input(fshape, batch_size=n_batch)
    x = TCN(
        nb_filters,
        kernel_size,
        nb_stacks,
        dilations,
        padding,
        use_skip_connections,
        dropout_rate,
        return_sequences=True,
        activation=activation,
        kernel_initializer="random_normal",
        use_batch_norm=True,
    )(inputs)

    x = Flatten()(x)
    x = Dense(2 * n_steps)(x)
    x = Activation("relu")(x)
    x = Dense(n_steps)(x)
    x = Activation("relu")(x)
    x = Dense(code_size)(x)

    encoder = Model(inputs, x)
    return encoder


class TSCP2Model(keras.Model):
    def __init__(
            self,
            encoder: keras.Model,
            batch_size: int,
            temperature: float = 0.1,
            *args,
            **kwargs
    ):
        super(TSCP2Model, self).__init__(*args, **kwargs)
        self.encoder = encoder
        self.temperature = temperature
        self.nce_loss_func = NCELoss(batch_size=batch_size, temperature=temperature)
        self.mean_loss = keras.metrics.Mean(name="loss")
        self.sim_metrice = keras.metrics.Mean(name="sim")
        self.neg_metrice = keras.metrics.Mean(name="neg")

    @property
    def metrics(self):
        return [self.mean_loss, self.sim_metrice, self.neg_metrice]

    @tf.function
    def call(self, inputs, training=None, mask=None):
        return self.encoder(inputs, training=training, mask=mask)

    @tf.function
    def train_step(self, data):
        history, future = data
        with tf.GradientTape() as tape:
            history_code = self(history, training=True)
            future_code = self(future, training=True)

            history_code = tf.math.l2_normalize(history_code, axis=1)
            future_code = tf.math.l2_normalize(future_code, axis=1)
            loss, mean_sim, mean_neg = self.nce_loss_func(history_code, future_code)

        self.mean_loss.update_state(loss)
        self.sim_metrice.update_state(mean_sim)
        self.neg_metrice.update_state(mean_neg)

        trainable_vars = self.trainable_variables
        gradients = tape.gradient(loss, trainable_vars)
        self.optimizer.apply_gradients(zip(gradients, trainable_vars))

        return {
            "loss": self.mean_loss.result(),
            "sim": self.sim_metrice.result(),
            "neg": self.neg_metrice.result(),
        }

    @tf.function
    def test_step(self, data):
        history, future = data
        history_code = self(history, training=False)
        future_code = self(future, training=False)

        history_code = tf.math.l2_normalize(history_code, axis=1)
        future_code = tf.math.l2_normalize(future_code, axis=1)
        loss, mean_sim, mean_neg = self.nce_loss_func(history_code, future_code)

        self.mean_loss.update_state(loss)
        self.sim_metrice.update_state(mean_sim)
        self.neg_metrice.update_state(mean_neg)

        return {
            "loss": self.mean_loss.result(),
            "sim": self.sim_metrice.result(),
            "neg": self.neg_metrice.result(),
        }
