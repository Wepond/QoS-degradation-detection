import os
import pickle
import tensorflow as tf
import keras.backend as K
from tensorflow import keras

import constants
from utils import *
from model_CL import ContinualLearningModel


def load_dataset(path):
    with open(path, 'rb') as f:
        train_data = pickle.load(f)
    return train_data[0], train_data[2], train_data[3]


def generate_train_data(data, delta, label):
    train_dataset = tf.data.Dataset.from_tensor_slices(
        (data, delta, label))

    train_data = train_dataset.batch(constants.BATCH_SIZE,
                                     drop_remainder=True).prefetch(
        tf.data.experimental.AUTOTUNE
    )
    return train_data


class Experiments:
    def __init__(self, encoder):
        self.encoder = encoder
        self.cl_model = None
        print("> Experiments Initialized.")

    def run_replay_experiment(self, experiment_name, use_case,
                              replay_size=10000,
                              random_selection=False, config=None):
        print("> Running Replay experiment")


        train_data, train_delta, train_label = load_dataset(os.path.join(constants.DATASET_PKL_DIR, 'train.pkl'))
        test_data, test_delta, test_label = load_dataset(os.path.join(constants.DATASET_PKL_DIR, 'val.pkl'))

        test_dataset = generate_train_data(test_data, test_delta,
                                           test_label)

        self.cl_model = ContinualLearningModel(name=use_case,
                                               replay_buffer=replay_size,
                                               encoder=self.encoder)
        self.cl_model.build_complete_model(config)

        print("Start Trainning....")

        batch_num = int(len(train_data) / constants.TASK_SIZE)
        print('Total batch:', batch_num)
        for batch in range(batch_num):
            _train_x = train_data[batch * constants.TASK_SIZE:(batch + 1) * constants.TASK_SIZE]
            _train_delta = train_delta[batch * constants.TASK_SIZE:(batch + 1) * constants.TASK_SIZE]
            _train_label = train_label[batch * constants.TASK_SIZE:(batch + 1) * constants.TASK_SIZE]

            print("----------- batch {} -------------".format(batch))
            print("train_x shape: {}".format(_train_x.shape))


            # if batch == 1:
            #     K.set_value(self.cl_model.model.optimizer.lr, 0.00005)

            shuffle_in_unison([_train_x, _train_delta, _train_label],
                              in_place=True)

            train_dataset = generate_train_data(_train_x,
                                                _train_delta,
                                                _train_label)

            print('Cur model learning rate:')
            print(self.cl_model.model.optimizer.lr)

            # try to load model
            latest = tf.train.latest_checkpoint(
                checkpoint_dir=config.get_ckpt_dir("mtqos" + str(batch)))
            if latest is not None:
                print("load model {} now.".format(latest))
                self.cl_model.model.load_weights(latest)
                initial_epoch = int(os.path.basename(latest).split("-")[0])
                print("update initial_epoch ->", initial_epoch)

            callbacks = [
                keras.callbacks.ModelCheckpoint(
                    filepath=config.get_ckpt_file("mtqos" + str(batch)),
                    monitor="val_mse",
                    verbose=2,
                    save_best_only=False,
                    save_weights_only=False,
                ),
                keras.callbacks.TensorBoard(
                    log_dir=config.get_log_dir(config.model_name)),
            ]
            # replay_callbacks
            replay_callbacks = [
                keras.callbacks.ModelCheckpoint(
                    filepath=config.get_ckpt_file("replay_mtqos" + str(batch)),
                    monitor="val_mse",
                    verbose=2,
                    save_best_only=False,
                    save_weights_only=False,
                ),
                keras.callbacks.TensorBoard(
                    log_dir=config.get_log_dir(config.model_name)),
            ]
            self.cl_model.model.fit(train_dataset,
                                    validation_data=test_dataset,
                                    epochs=40, verbose=2, batch_size=constants.BATCH_SIZE,
                                    callbacks=callbacks)
            if batch >= 1:
                self.cl_model.replay(replay_callbacks)
            self.cl_model.store_representations(_train_x, _train_delta,
                                                _train_label,
                                                random_select=random_selection)

            print("---------------------------------")

        latest = tf.train.latest_checkpoint(
            config.get_ckpt_dir("mtqos" + str(batch_num - 1)))
        self.cl_model.model.load_weights(latest).expect_partial()
        print(self.cl_model.model.evaluate(test_dataset))
        print("Save Trainer")
        self.cl_model.model.save(config.model_dir, save_format="tf")

